----------
To Compile
----------
1. Extract the "Projects" folder and place inside the main LLVM_Trax directory.
2. Go into "Projects > HW5a".
3. Run command: "make"

